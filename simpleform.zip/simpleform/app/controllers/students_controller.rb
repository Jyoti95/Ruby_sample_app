class StudentsController < ApplicationController

def new
	@student=Student.new
	#@students=Student.find(1,2)
	#@students=Student::find;
	@students=Student.all
end



def create
	#@student=Student.new(params[:student])
	@student=Student.new(params_student)
	if @student.save
	redirect_to new_student_path 
		#flash.now[:notice] = 'Thank you for your message!'
	
	end
	
end
 
private

  def params_student
    params.require(:student).permit(:firstname, :lastname)
  end

#def student_param
#	params.require(:student).permit(:firstname, :lastname)
	
#end

end
